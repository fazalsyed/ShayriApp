//
//  CellC_TypePoetry.swift
//  ShaairanaSafar
//
//  Created by syed fazal abbas on 09/09/23.
//

import UIKit

class CellC_TypePoetry: UICollectionViewCell {

    @IBOutlet var vwTypePotery: UIView!
    @IBOutlet var img_PoetryType: UIImageView!
    @IBOutlet var lbl_PoetryType: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
