//
//  Struct.swift
//  ShaairanaSafar
//
//  Created by syed fazal abbas on 09/09/23.
//

import Foundation


//Marks : Struct is For Poetry Type 
struct Poetry{
    var PoetryType : String?
    var Poteryimg  : String?
    init(PoetryType: String, Poteryimg: String) {
        self.PoetryType = PoetryType
        self.Poteryimg = Poteryimg
    }
}


