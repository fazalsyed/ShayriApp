//
//  CellT_PoetryDetail.swift
//  ShaairanaSafar
//
//  Created by syed fazal abbas on 09/09/23.
//

import UIKit

class CellT_PoetryDetail: UITableViewCell {

    @IBOutlet var vwPoetryDetail: UIView!
    @IBOutlet var txtView: UITextView!
    
    @IBOutlet var btnShareAll: UIButton!
    @IBOutlet var btnShareWhatsapp: UIButton!
    @IBOutlet var btnCopyText: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
