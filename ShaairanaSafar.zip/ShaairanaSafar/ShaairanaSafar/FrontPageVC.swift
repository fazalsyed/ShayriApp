//
//  FrontPageVC.swift
//  ShaairanaSafar
//
//  Created by syed fazal abbas on 10/09/23.
//

import UIKit

class FrontPageVC: UIViewController {

    @IBOutlet var img_icon: UIImageView!
    @IBOutlet var btnNext: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        img_icon.layer.cornerRadius = 10
        btnNext.layer.cornerRadius = 10
        btnNext.layer.borderColor = UIColor.systemYellow.cgColor
        btnNext.layer.borderWidth = 3
    }
    
    @IBAction func btnTappedNext(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
}
