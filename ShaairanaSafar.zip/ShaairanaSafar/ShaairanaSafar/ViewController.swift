//
//  ViewController.swift
//  ShaairanaSafar
//
//  Created by syed fazal abbas on 09/09/23.
//

import UIKit

class ViewController: UIViewController {
 var ArrPoetry = [Poetry]()
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_TypePoetry", bundle: nil), forCellWithReuseIdentifier: "CellC_TypePoetry")
        arryPoetry()
    }
    func arryPoetry(){
        ArrPoetry = [Poetry(PoetryType: "Love", Poteryimg: "ic_Love"),Poetry(PoetryType: "Break UP", Poteryimg: "ic_BreakUP"),Poetry(PoetryType: "Romatic", Poteryimg: "ic_Romatic"),Poetry(PoetryType: "Long Distance", Poteryimg: "ic_LongDistance"),Poetry(PoetryType: "Sad", Poteryimg: "ic_Sad"),Poetry(PoetryType: "Life", Poteryimg: "ic_Life"),Poetry(PoetryType: "Funny", Poteryimg: "ic_Funny"),Poetry(PoetryType: "Valentine", Poteryimg: "ic_Valentine"),Poetry(PoetryType: "Forgiveness", Poteryimg: "ic_Forgiveness"),Poetry(PoetryType: "Motivational", Poteryimg: "ic_Motivational"),Poetry(PoetryType: "Emotional", Poteryimg: "ic_Emotional"),Poetry(PoetryType: "Friend", Poteryimg: "ic_Friend"),Poetry(PoetryType: "Father", Poteryimg: "ic_Father"),Poetry(PoetryType: "Mother", Poteryimg: "ic_Mother"),Poetry(PoetryType: "Sibling", Poteryimg: "ic_Sibling"),Poetry(PoetryType: "Men", Poteryimg: "ic_Men"),Poetry(PoetryType: "Women", Poteryimg: "ic_Women"),Poetry(PoetryType: "Relative", Poteryimg: "ic_Relative"),Poetry(PoetryType: "Rain", Poteryimg: "ic_Rain"),Poetry(PoetryType: "Morning", Poteryimg: "ic_Morning"),Poetry(PoetryType: "Night", Poteryimg: "ic_Night"),Poetry(PoetryType: "Winter", Poteryimg: "ic_Winter"),Poetry(PoetryType: "Summer", Poteryimg: "ic_Summer"),Poetry(PoetryType: "Defeat", Poteryimg: "ic_Defeat")]
    }
}
extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ArrPoetry.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_TypePoetry", for: indexPath) as! CellC_TypePoetry
        cell.lbl_PoetryType.text = ArrPoetry[indexPath.row].PoetryType
        cell.img_PoetryType.image = UIImage(named: ArrPoetry[indexPath.row].Poteryimg!)
        cell.vwTypePotery.layer.cornerRadius = 8
        cell.vwTypePotery.layer.borderWidth = 1
        cell.vwTypePotery.layer.borderColor = UIColor.gray.cgColor
        cell.img_PoetryType.layer.cornerRadius = 8
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PoetryDetailVC") as? PoetryDetailVC
        vc?.selectedIndex = indexPath.row
        self.navigationController?.pushViewController(vc!, animated: true)
    }
            func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
                return 0
            }
            func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
                return 0
            }
            func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
                let size = collectionView.bounds.width
                return CGSize(width: size/2-2, height: size/2-2)
            }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 2)
    }
}

